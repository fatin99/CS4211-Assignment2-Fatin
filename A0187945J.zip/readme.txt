Problem 1: run `NuSMV problem-1.smv`
Problem 2: run `NuSMV problem-2.smv`
Problem 3: run `NuSMV problem-3.smv`